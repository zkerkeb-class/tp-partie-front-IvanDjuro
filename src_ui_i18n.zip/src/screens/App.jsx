import './App.css'
import PokeList from '../components/pokelist'

function App() {
  return (
    <div>
      <PokeList />
    </div>
  )
}

export default App
